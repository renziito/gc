<?php
declare(strict_types=1);
require dirname(__DIR__).'/app/bootstrap.php';
if(($_SERVER['REQUEST_METHOD']??'GET')!=='GET'){header('Allow: GET'); respondError(405,'method_not_allowed','Only GET is supported.');}
function respond(array $data,int $status=200,array $meta=[]):never{
 http_response_code($status);header('Content-Type: application/json; charset=utf-8');header('Cache-Control: public, max-age=30, stale-while-revalidate=60');header('X-Content-Type-Options: nosniff');
 echo json_encode(['ok'=>true,'data'=>$data,'meta'=>array_merge(['generated_at'=>gmdate('c')],$meta)],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);exit;
}
function respondError(int $status,string $code,string $message):never{
 http_response_code($status);header('Content-Type: application/json; charset=utf-8');header('X-Content-Type-Options: nosniff');
 echo json_encode(['ok'=>false,'error'=>['code'=>$code,'message'=>$message],'meta'=>['generated_at'=>gmdate('c')]],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);exit;
}
$path=parse_url($_SERVER['REQUEST_URI']??'/',PHP_URL_PATH)?:'/';$base=rtrim(dirname($_SERVER['SCRIPT_NAME']??''),'/');
if($base!==''&&str_starts_with($path,$base))$path=substr($path,strlen($base));$path='/'.trim($path,'/');
try{
 if($path==='/api/v1/health')respond(['service'=>'Galactic Command API','status'=>'up']);
 $map=[
  '/api/v1/war'=>['table'=>'source_payloads','source'=>'war','entity'=>null],
  '/api/v1/planets'=>['table'=>'source_payloads','source'=>'planets','entity'=>null],
  '/api/v1/orders'=>['table'=>'source_payloads','source'=>'assignments','entity'=>null],
  '/api/v1/campaigns'=>['table'=>'source_payloads','source'=>'campaigns','entity'=>null],
  '/api/v1/news'=>['table'=>'source_payloads','source'=>'dispatches','entity'=>null],
  '/api/v1/steam-news'=>['table'=>'source_payloads','source'=>'steam_news','entity'=>null],
  '/api/v1/space-stations'=>['table'=>'source_payloads','source'=>'space_stations','entity'=>null],
  '/api/v1/planet-events'=>['table'=>'source_payloads','source'=>'planet_events','entity'=>null],
 ];
 if(isset($map[$path])){
  $m=$map[$path];$q=$pdo->prepare('SELECT fetched_at,http_status,payload_json FROM source_payloads WHERE source_key=? AND entity_key IS NULL ORDER BY id DESC LIMIT 1');$q->execute([$m['source']]);$r=$q->fetch();
  if(!$r)respondError(503,'data_not_ready','No synchronized data is available yet.');
  $data=json_decode($r['payload_json'],true);respond($data,200,['source_key'=>$m['source'],'source_fetched_at'=>$r['fetched_at'],'source_http_status'=>(int)$r['http_status'],'contract_version'=>'raw-v1']);
 }
 if(preg_match('#^/api/v1/space-stations/([0-9]+)$#',$path,$m)){
  $id32=$m[1];$q=$pdo->prepare("SELECT fetched_at,http_status,payload_json FROM source_payloads WHERE source_key='space_station_by_index' AND entity_key=? ORDER BY id DESC LIMIT 1");$q->execute([$id32]);$r=$q->fetch();
  if(!$r)respondError(503,'data_not_ready','Station detail has not been synchronized. Run sync with --source=space_station_by_index --id32='.$id32.'.');
  respond(json_decode($r['payload_json'],true),200,['source_key'=>'space_station_by_index','id32'=>$id32,'source_fetched_at'=>$r['fetched_at']]);
 }
 if(preg_match('#^/api/v1/planets/([0-9]+)$#',$path,$m)){
  $q=$pdo->prepare('SELECT raw_json FROM planets WHERE upstream_index=? LIMIT 1');$q->execute([(int)$m[1]]);$r=$q->fetch();
  if(!$r)respondError(404,'planet_not_found','Planet index not found.');
  respond(json_decode($r['raw_json'],true),200,['planet_index'=>(int)$m[1]]);
 }
 respondError(404,'not_found','Endpoint not found.');
}catch(Throwable $e){error_log('[Galactic Command API] '.$e->getMessage());respondError(500,'internal_error','An unexpected server error occurred.');}
